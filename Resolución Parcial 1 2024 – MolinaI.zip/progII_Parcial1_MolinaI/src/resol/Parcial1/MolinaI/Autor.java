package resol.Parcial1.MolinaI;

import java.util.ArrayList;

public class Autor extends Persona{

	private String nacionalidad;
	private enum estilo{Novela, Cuento, Poes�a, Ensayo, Biogr�fico};
	private ArrayList<Libro> libros;
	
	public Autor() {
		
	}

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	

	public ArrayList<Libro> getLibros() {
		return libros;
	}

	public void setLibros(ArrayList<Libro> libros) {
		this.libros = libros;
	}

	public Autor(String nombre, String apellido, String email,String nacionalidad, ArrayList<Libro> libros) {
		super(nombre,apellido,email);
		this.nacionalidad = nacionalidad;
	
		this.libros = libros;
	}

	
}
