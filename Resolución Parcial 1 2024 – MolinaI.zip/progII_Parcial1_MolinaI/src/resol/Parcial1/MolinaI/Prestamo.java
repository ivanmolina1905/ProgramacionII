package resol.Parcial1.MolinaI;

import java.time.LocalDate;

public class Prestamo {

	private Libro libro;
	private	Usuario usuario;
	private LocalDate fechaDevolucion;
	private LocalDate fechaPrestamo;
	
	public Prestamo() {
		// TODO Auto-generated constructor stub
	}

	public Libro getLibro() {
		return libro;
	}

	public void setLibro(Libro libro) {
		this.libro = libro;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public LocalDate getFechaDevolucion() {
		return fechaDevolucion;
	}

	public void setFechaDevolucion(LocalDate fechaDevolucion) {
		this.fechaDevolucion = fechaDevolucion;
	}

	public LocalDate getFechaPrestamo() {
		return fechaPrestamo;
	}

	public void setFechaPrestamo(LocalDate fechaPrestamo) {
		this.fechaPrestamo = fechaPrestamo;
	}

	public Prestamo(Libro libro, Usuario usuario, LocalDate fechaDevolucion,LocalDate fechaPrestamo) {
		this.libro = libro;
		this.usuario = usuario;
		this.fechaDevolucion = fechaDevolucion;
		this.fechaPrestamo = fechaPrestamo;
	}

	
}
