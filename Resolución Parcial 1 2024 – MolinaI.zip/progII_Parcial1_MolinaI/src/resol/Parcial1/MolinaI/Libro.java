package resol.Parcial1.MolinaI;

import java.util.ArrayList;

public class Libro {

	private int identificador;
	private String titulo;
	private String ISBN;
	private ArrayList<Autor> autores;
	
	public Libro() {
		// TODO Auto-generated constructor stub
	}

	public int getIdentificador() {
		return identificador;
	}

	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public ArrayList<Autor> getAutores() {
		return autores;
	}

	public void setAutores(ArrayList<Autor> autores) {
		this.autores = autores;
	}

	public Libro(int identificador, String titulo, String iSBN,ArrayList<Autor> autores) {
		this.identificador = identificador;
		this.titulo = titulo;
		this.ISBN = iSBN;
		this.autores = autores;
	}

}
