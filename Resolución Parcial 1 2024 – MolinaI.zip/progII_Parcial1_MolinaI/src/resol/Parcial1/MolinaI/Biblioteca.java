package resol.Parcial1.MolinaI;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Biblioteca {

	private String nombre;
	private String localidad;
    private String direccion;
	private List libros;
	private List autores;
	private List usuarios;
	private List prestamos;
	
	public Biblioteca(String nombre, String localidad, String direccion) {
		this.nombre = nombre;
		this.localidad = localidad;
		this.direccion = direccion;
		this.libros=new ArrayList<Libro>();
		this.autores=new ArrayList<Autor>();
		this.usuarios=new ArrayList<Usuario>();
		this.prestamos=new ArrayList<Prestamo>();
		
		
	}
	
	public void AgregarLibros(Libro a){
		libros.add(a);
	}
	
	public void AgregarAutor(Autor a){
		autores.add(a);
	}
	
	public void AgregarUsuario(Usuario a){
		usuarios.add(a);
	}
	
	public void prestarLibro(Libro libro, Usuario usuario, LocalDate fechaDevolucion,LocalDate fechaPrestamo){
		Prestamo nuevop=new Prestamo(libro,usuario,fechaDevolucion,fechaPrestamo);
		prestamos.add(nuevop);
	}
	
	public void devolverLibro(Libro libro, LocalDate Fechadevolucion){
		
		int id=libro.getIdentificador();
		
		
		for(int i=0;i<prestamos.size();i++){
		if(prestamos.get(i)){
			
		}
			
		}
			
	}
	
	
	public Biblioteca() {
		
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getLocalidad() {
		return localidad;
	}


	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}






	
}
