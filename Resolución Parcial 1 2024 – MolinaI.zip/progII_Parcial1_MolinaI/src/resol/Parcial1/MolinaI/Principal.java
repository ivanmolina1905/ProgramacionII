package resol.Parcial1.MolinaI;

public class Principal {
	public static void main(String[] args) {
	
		
		Biblioteca biblioteca=new Biblioteca("Biblioteca Popular ICOP","Santa Fe","San Martin 1550");
		
		biblioteca.

	}

}
