package resol.Parcial1.MolinaI;

public class Usuario extends Persona{
	
	private int nafiliacion;
	private String direccion;

	private enum tipoSuscripcion{Regular,Premiun};
	
	public Usuario() {
		// TODO Auto-generated constructor stub
	}

	public int getNafiliacion() {
		return nafiliacion;
	}

	public void setNafiliacion(int nafiliacion) {
		this.nafiliacion = nafiliacion;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	

	public Usuario(String nombre, String apellido, String email,int nafiliacion, String direccion) {
		super(nombre,apellido,email);
		this.nafiliacion = nafiliacion;
		this.direccion = direccion;
		
	}

}
