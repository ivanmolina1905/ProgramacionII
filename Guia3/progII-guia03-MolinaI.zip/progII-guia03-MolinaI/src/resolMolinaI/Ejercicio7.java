package resolMolinaI;

public class Ejercicio7 {
		
	public static void ejecutar(String palabra) {
		System.out.println("El tamaño de la palabra es: "+palabra.length());
	}
}
