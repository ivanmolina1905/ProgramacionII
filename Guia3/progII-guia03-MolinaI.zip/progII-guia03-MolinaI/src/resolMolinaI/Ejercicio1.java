package resolMolinaI;

import java.util.Scanner;

public class Ejercicio1 {
	
	
	public static void ejecutar() {
		System.out.print("Ingrese su nombre");
	Scanner scanner=new Scanner(System.in);
	String nombre=scanner.nextLine();
	System.out.print("El nombre es: "+ nombre);;
	}
}
