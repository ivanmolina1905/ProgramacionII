package resolMolinaI;

public class Ejercicio11 {

	public static void ejecutar(int n, double a,char c) {
	
		System.out.println("El valor del entero es: "+n);
		System.out.println("El valor del double es: "+a);
		System.out.println("El valor del char es: "+c);
		System.out.println("la suma del entero mas el double es : "+(n+(double)a));
		System.out.println("la diferencia del double y el entero es: "+ (a-(double)n));
		System.out.println("El valor del caracter es: "+(int)a);
		System.out.println("El valor del la suma de todo es: "+(n+(double)a+(double)c));
	}
}
